import React, { useState, useEffect } from 'react';
import LoadingScreen from './loading';
import '@fontsource/mea-culpa';
import 'bootstrap/dist/css/bootstrap.min.css';
import './YourStyles.css';

const App = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      {loading && <LoadingScreen />}

      {!loading && (
        <div>
          <nav className="navbar navbar-expand-lg navbar-light" style={{ backgroundColor: 'rgb(255, 192, 192)' }}>
            <div className="container">
              <a
                className="navbar-brand"
                href="#"
                style={{
                  fontFamily: "'Mea Culpa', sans-serif",
                  color: 'black',
                  fontSize: '45px'
                }}
              >
                RadiantRings
              </a>

              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>

              <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav ml-auto">
                  <li className="nav-item">
                    <a
                      className="navbar-brand"
                      href="#"
                      style={{
                        fontFamily: "'Mea Culpa', sans-serif",
                        color: 'black',
                        fontSize: '30px'
                      }}
                    >
                      Home
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
                        <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4z" />
                      </svg>
                    </a>
                  </li>
                  <li className="nav-item">
                    <a
                      className="navbar-brand"
                      href="#"
                      style={{
                        fontFamily: "'Mea Culpa', sans-serif",
                        color: 'black',
                        fontSize: '30px'
                      }}
                    >
                      Planificación
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar-check" viewBox="0 0 16 16">
                        <path d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0" />
                        <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5M1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4z" />
                      </svg>
                    </a>
                  </li>
                  <li className="nav-item">
                    <a
                      className="navbar-brand"
                      href="#"
                      style={{
                        fontFamily: "'Mea Culpa', sans-serif",
                        color: 'black',
                        fontSize: '30px'
                      }}
                    >
                      Wedding planners
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-arms-up" viewBox="0 0 16 16">
                        <path d="M8 3a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3" />
                        <path d="m5.93 6.704-.846 8.451a.768.768 0 0 0 1.523.203l.81-4.865a.59.59 0 0 1 1.165 0l.81 4.865a.768.768 0 0 0 1.523-.203l-.845-8.451A1.5 1.5 0 0 1 10.5 5.5L13 2.284a.796.796 0 0 0-1.239-.998L9.634 3.84a.7.7 0 0 1-.33.235c-.23.074-.665.176-1.304.176-.64 0-1.074-.102-1.305-.176a.7.7 0 0 1-.329-.235L4.239 1.286a.796.796 0 0 0-1.24.998l2.5 3.216c.317.316.475.758.43 1.204Z" />
                      </svg>
                    </a>
                  </li>
                  {/* Agrega más elementos según sea necesario */}
                  <li className="nav-item">
                    <a
                      className="navbar-brand"
                      href="#"
                      style={{
                        color: 'black',
                        fontSize: '30px'
                      }}
                    >
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart3" viewBox="0 0 16 16">
  <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
</svg>
                    </a>
                  </li>
                  <li className="nav-item dropdown">
                    <a
                      className="navbar-brand dropdown-toggle"
                      href="#"
                      id="navbarDropdown"
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                      style={{
                        fontFamily: "'Mea Culpa', sans-serif",
                        color: 'black',
                        fontSize: '30px'
                      }}
                    >
                      Wedding Plans
                    </a>
                    <ul className="dropdown-menu" aria-labelledby="navbarDropdown" style={{ fontFamily: "'Mea Culpa', sans-serif" }}>
                      <li>
                        <a className="dropdown-item" href="#" style={{ color: 'gold' }}>
                          Wedding Gold
                        </a>
                      </li>
                      <li>
                        <a className="dropdown-item" href="#" style={{ color: 'silver' }}>
                          Wedding Silver
                        </a>
                      </li>
                      <li>
                        <a className="dropdown-item" href="#" style={{ color: '#b87333' }}>
                          Wedding Bronze
                        </a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <h1 style={{ fontSize: '50px', fontFamily: "'Mea Culpa', sans-serif", color: 'black' }}>
              Bienvenid@ a RadiantRings
            </h1>
            {/* Otros componentes y contenido */}
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
