  // Función para agregar un producto al carrito
  function agregarAlCarrito(producto) {
    var listaCarrito = document.getElementById('listaCarrito');
    var nuevoItem = document.createElement('li');
    nuevoItem.textContent = producto;
    listaCarrito.appendChild(nuevoItem);
    alert('Producto agregado al carrito: ' + producto);
  }

  // Función para mostrar el carrito al hacer clic en "Carrito"
  function verCarrito() {
    // Muestra el modal del carrito
    var carritoModal = new bootstrap.Modal(document.getElementById('carritoModal'));
    carritoModal.show();
  }

  // Función para realizar el pago (puedes implementar lógica adicional aquí)
  function realizarPago() {
    alert('¡Pago realizado con éxito!');
  }



var productosLink = document.getElementById("productosLink");

// Agrega un evento de clic al enlace
productosLink.addEventListener("click", function(event) {
  // Evita la acción predeterminada del enlace (evita que cargue una nueva página)
  event.preventDefault();

  // Llama a la función en main.js que carga los productos
  cargarProductos();
});
// Función para agregar un producto al carrito
function agregarAlCarrito(producto) {
var listaCarrito = document.getElementById('listaCarrito');
var nuevoItem = document.createElement('li');
nuevoItem.innerHTML = `
${producto}
<button type="button" class="btn btn-danger btn-sm mx-2" onclick="eliminarDelCarrito(this)">-</button>
<button type="button" class="btn btn-primary btn-sm" onclick="agregarUnidad(this)">+</button>
`;
listaCarrito.appendChild(nuevoItem);
alert('Producto agregado al carrito: ' + producto);
}

// Función para eliminar un producto del carrito
function eliminarDelCarrito(btn) {
var listItem = btn.parentNode;
listItem.parentNode.removeChild(listItem);
}

// Función para agregar una unidad más al producto en el carrito
function agregarUnidad(btn) {
var listItem = btn.parentNode;
var producto = listItem.firstChild.nodeValue.trim();
alert('Agregada una unidad más de: ' + producto);
}

