import React from 'react';
import './LoadingScreen.css';
import '@fontsource/mea-culpa';

const LoadingScreen = () => {
  return (
    <div className="loading-screen">
      <h1 className="loading-text text-silver" style={{ fontStyle: 'italic' }}>
        RadiantRings
      </h1>
    </div>
  );
};

export default LoadingScreen;
