import React from 'react';
import './MainContent.css';

const MainContent = () => {
  return (
    <div className="main-content">
      <h1>Radiant Rings</h1>
      {/* Agrega más contenido según sea necesario */}
    </div>
  );
};

export default MainContent;
